public class Ex11{
	public static void main(String[] args) {

		int no1 = 4;
		int no2 = 3;

		System.out.println("The result of the calculation is "+ multiply(no1, no2));

	}

	static int multiply(int number1 number 2){

		return number1 * Number2;
	}
}