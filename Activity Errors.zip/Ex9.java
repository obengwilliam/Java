public class Ex9{
	public static void main(String[] args) {

		double no = 4.2;

		System.out.println("The result of the calculation is "+ square(no));

	}

	static int square(double number){

		return number * number;
	}
}