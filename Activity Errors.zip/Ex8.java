public class Ex8{
	public static void main(String[] args) {

		int no = 4;

		System.out.println("The result of the calculation is "+ square(no));

	}

	static String square(int number){

		return number * number;
	}
}