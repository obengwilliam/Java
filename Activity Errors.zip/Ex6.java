public class Ex6{
	public static void main(String[] args) {

		int no = 4;

		System.out.println("The result of the calculation is "+ square(no));

	}

	static int square(int number){

		return numbr * number;
	}
}