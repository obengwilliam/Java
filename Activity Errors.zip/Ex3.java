public class Ex3{
	public static void main(String[] args) {
		
		String message = "Hello everyone!";
		printMessage(message);

	}

	void printMessage(String message){
		System.out.println(message);
	}
}