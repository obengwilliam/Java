public class Ex4{
	public static void main(String[] args) {
		
		String message = "Hello everyone!";
		printMessage(message);

	}

	static void printMessage(message){
		System.out.println(message);
	}
}