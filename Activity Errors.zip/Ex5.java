public class Ex5{
	public static void main(String[] args) {
		
		int number = 4;

		System.out.println("The result of the calculation is "+ square(number));

	}

	static void square(int number){

		return number * number;
	}
}