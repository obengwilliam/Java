public class Ex10{
	public static void main(String[] args) {

		int no = 4;

		System.out.println("The result of the calculation is "+ square(no));

	}

	static int square(int number){

		return no * no;
	}
}